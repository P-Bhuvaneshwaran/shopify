import React from "react";
import { NavLink } from "react-router-dom";
// import '../../Styles/auth.css'
const Signup = () =>{
    return(
        <div className="signupPage" id="authDiv">
            <div id="auth-container">
                <h2>Continue</h2>
                <form action="">
                    <div id="auth-fields">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="" placeholder="Enter Your Name" />
                        <p class="errMsg">Error</p>
                    </div>
                    <div id="auth-fields">
                        <label for="email">Email</label>
                        <input type="text" name="email" id="" placeholder="Enter Your Email Address" />
                        <p class="errMsg">Error</p>
                    </div>
                    <div id="auth-fields">
                        <label for="password">Password</label>
                        <input type="password" placeholder="Enter Your Password" name="password" />
                        <p class="errMsg">Error</p>
                    </div>
                    <div id="auth-fields">
                        <input type="submit" value="Signup" />
                        <p>Already have an account?  <NavLink to={'/auth-login'}>Login</NavLink></p>
                    </div>
                </form>
            </div>
        </div>
    )
}

export default Signup;