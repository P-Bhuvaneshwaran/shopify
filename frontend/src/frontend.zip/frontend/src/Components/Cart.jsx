import React from "react";
import '../Styles/cart.css'
import { NavLink } from "react-router-dom";
const Cart = () =>{

    const value = 1;
    return(
        <div className="cartPage">
            
            <div id="cartItems">
                
                {
                    value >0 ?
                <table>
                        <tr>
                        <th>Item</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Action</th>
                    </tr>
                    <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/duke.jpeg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by KTM</p>
                                <p >The product is manufactured by ktm.com.in in Capital of New Delhi
                                The product is manufactured by ktm.com.in in Capital of New Delhi
                                The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark">
                        <span>Remove from cart</span>
                        </i>
                            
                        </td>
                    </tr>
                
                
                </table>
                : 
                <div id="emtCartDiv">
                    <img src="/src/images/ktm.jpg" alt="" />
                    <p id="emtCartMsg"> Please Add items to the cart</p>
                    <button><NavLink to={'/products'}>Add Items to Cart</NavLink></button>
                </div>
                }
                
                
                
                    {/* <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/sub.jpeg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by KTM</p>
                                <p>The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark"></i></td>
                    </tr>
                    <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/hd.jpeg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by KTM</p>
                                <p>The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark"></i></td>
                    </tr>
                    <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/duke.jpeg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by KTM</p>
                                <p>The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark"></i></td>
                    </tr>
                    
                    <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/hd.jpeg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by <span>KTm</span></p>
                                <p>The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark"></i></td>
                    </tr>
                
                    <tr>
                        <td>
                            <div id="img--div">
                                <img src="/src/images/img1.jpg" alt="" />
                            </div>
                            <div id="img--details">
                                <p>Duke 200</p>
                                <p>by <span>KTm</span></p>
                                <p>The product is manufactured by ktm.com.in in Capital of New Delhi
                                The product is manufactured by ktm.com.in in Capital of New Delhi</p>
                            </div> 
                        </td>
                        <td>$ 2,80,876</td>
                        <td> 
                            <span>
                                <button>-</button>
                                <input type="text" />
                                <button>+</button>
                            </span>
                        </td>
                        <td>$ 2,80,987</td>
                        <td><i class="fa-solid fa-xmark"></i></td>
                    </tr>
                 */}


                
                {/* </table>     */}
            </div>
        </div>
    )
}

export default Cart;