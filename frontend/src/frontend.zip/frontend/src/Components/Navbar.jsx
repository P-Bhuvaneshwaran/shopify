import React from "react";
import '../Styles/navbar.css'
import { NavLink } from "react-router-dom";
const Navbar = () =>{

//  under working

    const isBadge = 1;

    const slideuser =document.querySelector("#slide-user");
    const slidebarUser = ()=>{
        console.log("hai");
            slideuser.classList.toggle("slide-bar-user")
    }
    return(
        <div className="navbarPage">    
            <div id="nav-container">
                <nav>
                    <h1>Bhuvi.11</h1>
                    <ul>
                        <li><NavLink to={'/home'} end>Home</NavLink></li>
                        <li><NavLink to={'/about-us'}>About</NavLink></li>
                        <li><NavLink to={'/products'}>Products</NavLink></li>
                        <li><NavLink to={'/offer-items'}>Offers</NavLink></li>
                        <li><NavLink to={'/contact-us'}>Contact</NavLink></li>
                    </ul>
                    <div id="nav-icons">
                        {/* <i class=></i> */}
                        <NavLink to={'/cart-items'}><i class="fa-solid fa-cart-shopping"></i></NavLink>
                        <i class="fa-solid fa-user" onClick={slidebarUser}></i>
                        {isBadge ? <div className="cart-badge">1</div> : ''}

                        <div id="slide-user">
                            <ul class="reddy">
                                <div>
                                    <li><NavLink to={'/auth-login'}>Login</NavLink></li>
                                </div>
                                <li>Welcome {'username'}</li>
                                <li>My details</li>
                                <li>dashboard</li>
                                <li>dashboard</li>
                                <li>dashboard</li>
                                <li>Home</li>
                            </ul>
                        </div>
                    </div>
    
                </nav>
            </div>
        </div>
    )
}

export default Navbar;